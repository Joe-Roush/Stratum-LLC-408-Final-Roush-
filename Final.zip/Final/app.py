import os
import random
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

# ---------------------------------------------
# App Setup
# ---------------------------------------------
app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

os.makedirs('database', exist_ok=True)
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

DATABASE = 'database/stratum.db'

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# ---------------------------------------------
# DB Helpers
# ---------------------------------------------
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# ---------------------------------------------
# User Model
# ---------------------------------------------
class User(UserMixin):
    def __init__(self, id, username, password_hash, is_admin):
        self.id = id
        self.username = username
        self.password_hash = password_hash
        self.is_admin = is_admin

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    user = conn.execute(
        "SELECT * FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    conn.close()
    if user:
        return User(user['id'], user['username'], user['password_hash'], user['is_admin'])
    return None

# ---------------------------------------------
# Create Tables + Seed Data
# ---------------------------------------------
def create_tables():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS programs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            filename TEXT NOT NULL,
            upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            author_id INTEGER NOT NULL,
            views INTEGER DEFAULT 0,
            rating REAL DEFAULT 0,
            rating_count INTEGER DEFAULT 0,
            FOREIGN KEY (author_id) REFERENCES users(id)
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            program_id INTEGER NOT NULL,
            purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()

def seed_default_admin():
    conn = get_db_connection()
    exists = conn.execute("SELECT * FROM users WHERE username = 'admin'").fetchone()
    if not exists:
        conn.execute(
            "INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)",
            ('admin', generate_password_hash('adminpass'), 1)
        )
        conn.commit()
    conn.close()

def seed_default_programs():
    conn = get_db_connection()
    admin = conn.execute("SELECT * FROM users WHERE username = 'admin'").fetchone()
    if not admin:
        return
    author_id = admin['id']

    count = conn.execute("SELECT COUNT(*) FROM programs").fetchone()[0]
    if count >= 20:
        conn.close()
        return

    example_trainings = [
        ("Basic Handgun Safety", "Introduction to handgun safety."),
        ("Rifle Marksmanship", "Intermediate rifle marksmanship."),
        ("Advanced Tactical Pistol", "High-level pistol drills."),
        ("Home Defense Strategies", "Defensive shooting and planning."),
        ("Shotgun Fundamentals", "Basics of shotgun operation."),
        ("Urban Combat Drills", "Simulated urban combat scenarios."),
        ("Concealed Carry 101", "Legal and practical CCW training."),
        ("AR-15 Handling", "Safe handling of AR-15 rifles."),
        ("Close Quarters Shooting", "CQB tactical shooting."),
        ("Night Shooting Skills", "Low-light engagement techniques."),
        ("Firearms Maintenance", "Cleaning and upkeep."),
        ("Speed Reload Drills", "Improving reload speed."),
        ("Precision Rifle Shooting", "Long-range accuracy."),
        ("Tactical Shotgun Training", "Shotgun for tactical use."),
        ("Defensive Shooting Mindset", "Threat assessment training."),
        ("Advanced Carbine Drills", "Carbine combat handling."),
        ("Law Enforcement Tactics", "Police-style firearms use."),
        ("Emergency Response Shooting", "Rapid response skills."),
        ("Marksmanship Fundamentals", "Foundational shooting."),
        ("Beginner Gun Safety", "New shooter fundamentals.")
    ]

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    for i, (title, desc) in enumerate(example_trainings, start=1):
        filename = f"training{i}.txt"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        with open(filepath, 'w') as f:
            f.write(f"{title}\n{desc}\nSample training content.")

        views = random.randint(100, 900)
        rating = round(random.uniform(2.5, 5), 1)
        rating_count = random.randint(5, 40)

        conn.execute(
            '''
            INSERT INTO programs (title, description, filename, author_id, views, rating, rating_count)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''',
            (title, desc, filename, author_id, views, rating, rating_count)
        )

    conn.commit()
    conn.close()

create_tables()
seed_default_admin()
seed_default_programs()

# ---------------------------------------------
# Routes
# ---------------------------------------------
@app.route('/')
def index():
    return redirect(url_for('dashboard')) if current_user.is_authenticated else redirect(url_for('login'))

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password_hash'], password):
            login_user(User(user['id'], user['username'], user['password_hash'], user['is_admin']))
            return redirect(url_for('dashboard'))

        flash("Invalid credentials")
    return render_template('login.html')

# Register
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, generate_password_hash(password))
            )
            conn.commit()
        except:
            flash("Username already exists")
            conn.close()
            return redirect(url_for('register'))

        conn.close()
        flash("Registered successfully!")
        return redirect(url_for('login'))
    return render_template('register.html')

# Logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Dashboard
@app.route('/dashboard')
@login_required
def dashboard():
    sort = request.args.get('sort', 'date')
    page = int(request.args.get('page', 1))
    per_page = 10
    offset = (page - 1) * per_page
    query = request.args.get('q', '')

    conn = get_db_connection()

    sort_sql = {
        'views': 'views DESC',
        'rating': 'rating DESC',
        'date': 'upload_date DESC'
    }.get(sort, 'upload_date DESC')

    base_sql = 'SELECT * FROM programs WHERE 1=1'
    params = []

    if query:
        base_sql += ' AND (title LIKE ? OR description LIKE ?)'
        params.extend([f'%{query}%', f'%{query}%'])

    base_sql += f' ORDER BY {sort_sql} LIMIT ? OFFSET ?'
    params.extend([per_page, offset])

    programs = conn.execute(base_sql, params).fetchall()

    total_programs = conn.execute(
        'SELECT COUNT(*) FROM programs WHERE 1=1' + (' AND (title LIKE ? OR description LIKE ?)' if query else ''),
        ([f'%{query}%', f'%{query}%'] if query else [])
    ).fetchone()[0]

    conn.close()
    total_pages = max(1, (total_programs + per_page - 1) // per_page)

    return render_template(
        'dashboard.html',
        programs=programs,
        sort=sort,
        page=page,
        total_pages=total_pages,
        query=query
    )

# Upload
@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_program():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        file = request.files['file']
        filename = file.filename

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO programs (title, description, filename, author_id) VALUES (?, ?, ?, ?)',
            (title, description, filename, current_user.id)
        )
        conn.commit()
        conn.close()

        return redirect(url_for('dashboard'))

    return render_template('upload.html')

# Program View + Purchase + Rating
@app.route('/program/<int:program_id>', methods=['GET', 'POST'])
@login_required
def view_program(program_id):
    conn = get_db_connection()
    program = conn.execute(
        "SELECT * FROM programs WHERE id = ?", (program_id,)
    ).fetchone()

    if not program:
        conn.close()
        return "Program not found", 404

    purchased = conn.execute(
        "SELECT * FROM purchases WHERE user_id = ? AND program_id = ?",
        (current_user.id, program_id)
    ).fetchone()

    if request.method == 'POST':
        if 'purchase' in request.form and not purchased:
            conn.execute(
                "INSERT INTO purchases (user_id, program_id) VALUES (?, ?)",
                (current_user.id, program_id)
            )
            conn.commit()
            purchased = True

        if 'rating' in request.form and (purchased or current_user.is_admin):
            rating = float(request.form['rating'])
            old_rating = program['rating']
            old_count = program['rating_count']
            new_count = old_count + 1
            new_rating = round(((old_rating * old_count) + rating) / new_count, 1)
            conn.execute(
                'UPDATE programs SET rating = ?, rating_count = ? WHERE id = ?',
                (new_rating, new_count, program_id)
            )
            conn.commit()

    conn.execute("UPDATE programs SET views = views + 1 WHERE id = ?", (program_id,))
    conn.commit()
    program = conn.execute("SELECT * FROM programs WHERE id = ?", (program_id,)).fetchone()
    conn.close()

    return render_template('program_view.html', program=program, purchased=purchased)

# Download Route (Purchase Wall)
@app.route('/program/<int:program_id>/download')
@login_required
def download_program(program_id):
    conn = get_db_connection()
    purchase = conn.execute(
        "SELECT * FROM purchases WHERE user_id = ? AND program_id = ?",
        (current_user.id, program_id)
    ).fetchone()
    program = conn.execute("SELECT * FROM programs WHERE id = ?", (program_id,)).fetchone()
    conn.close()

    if not program:
        return "Program not found", 404
    if not purchase and not current_user.is_admin:
        return "You must purchase this program to download it.", 403

    return redirect(url_for('static', filename=f'uploads/{program["filename"]}'))

# Admin
@app.route('/admin')
@login_required
def admin():
    if not current_user.is_admin:
        return "ACCESS DENIED"

    conn = get_db_connection()
    users = conn.execute("SELECT * FROM users").fetchall()
    programs = conn.execute("SELECT * FROM programs").fetchall()
    purchases = conn.execute("SELECT * FROM purchases").fetchall()
    conn.close()

    return render_template('admin.html', users=users, programs=programs, purchases=purchases)

# Run
if __name__ == '__main__':
    app.run(debug=True)
